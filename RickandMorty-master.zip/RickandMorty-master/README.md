![N|Solid](https://kriminalinc.github.io/RickandMorty/src/images/rm-logo.png)

# Rick & Morty directory using The Rick & Morty API

Single page application with Vanilla JS.

[page] - View website

[api] - The Rick & marty API link

   [api]: <https://rickandmortyapi.com/>
   [page]: <https://kriminalinc.github.io/RickandMorty/>
